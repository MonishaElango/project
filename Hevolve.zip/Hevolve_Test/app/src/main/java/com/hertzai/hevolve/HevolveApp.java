package com.hertzai.hevolve;

import android.app.Application;
import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.hertzai.hevolve.constants.HevolveConstants;
import com.hertzai.hevolve.managers.SharedPrefManager;
import com.hertzai.hevolve.models.gson.User;

public class HevolveApp extends Application {

    public static boolean DEBUG = true;
    public static boolean FIRST_CHECK = true;
    private static String authToken;
    private static String email;
    private static User user;


    public static String getAuthToken(Context context) {
        if (authToken == null) {
            authToken = SharedPrefManager.getInstance(context).getPreferenceDefNull(HevolveConstants.LOGGED_IN_AUTH_TOKEN);
        }
        return authToken;
    }

    public static String getEmail(Context context) {
        if (email == null) {
            email = SharedPrefManager.getInstance(context).getPreferenceDefNull(HevolveConstants.LOGGED_IN_EMAIL);
        }
        return email;
    }
    public static User getUser(Context context) {
        if (user == null) {
            user = User.parse(SharedPrefManager.getInstance(context).getPreference(HevolveConstants.LOGGED_IN_USER_DATA));
        }
        return user;
    }

    public static void setUser(Context context, User user) {
        HevolveApp.user = user;
        SharedPrefManager.getInstance(context).setPreference(HevolveConstants.LOGGED_IN_USER_DATA, User.toJson(user));
    }
    public static void clearAll() {
        authToken = null;
        email = null;
        // user = null;
    }


}

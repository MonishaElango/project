package com.hertzai.hevolve.views;

import android.content.Intent;
import android.media.AudioFormat;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.google.protobuf.ByteString;
import com.hertzai.hevolve.R;
import com.hertzai.hevolve.restService.ServiceGenerator;

import kotlin.Unit;

public class GridViewActivity extends AppCompatActivity {

    private CardView askmeCard, assessCard, devEngCard,revCard;

    private final String clientId = "your-client-id";
    private final String clientSecret = "your-client-secret";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_grid_view);
        askmeCard = (CardView) findViewById(R.id.AskCard);
        assessCard = (CardView) findViewById(R.id.AssessCard);
        devEngCard = (CardView) findViewById(R.id.EnglishCard);
        revCard = (CardView) findViewById(R.id.RevisionCard);
        askmeCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GridViewActivity.this, AskMeChatActivity.class);
                Uri.parse(ServiceGenerator.API_BASE_URL  + "?client_id=" + clientId +"?client_secret" + clientSecret);

                startActivity(intent);
            }
        });
        assessCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GridViewActivity.this, AssessmentChatActivity.class);
                startActivity(intent);
            }
        });
        devEngCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                              CardView devEngCard =(CardView) view;
                Toast.makeText(GridViewActivity.this, "Card is currently locked!" , Toast.LENGTH_SHORT ).show();

            }
        });
        revCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GridViewActivity.this,RevisionChatActivity.class);
                startActivity(intent);

            }
        });
    }

}


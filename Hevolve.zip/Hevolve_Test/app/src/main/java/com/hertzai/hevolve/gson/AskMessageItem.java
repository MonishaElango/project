package com.hertzai.hevolve.gson;

public class AskMessageItem {


    public String message;
    public Boolean isReply;

    public AskMessageItem(String message, Boolean isReply) {
        this.message = message;
        this.isReply = isReply;
    }
}

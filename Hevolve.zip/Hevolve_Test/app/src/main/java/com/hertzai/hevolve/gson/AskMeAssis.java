package com.hertzai.hevolve.gson;

import com.google.gson.annotations.SerializedName;

public class AskMeAssis {
    @SerializedName("history")
    private String history;
    @SerializedName("text")
    private String text;

    public String getHistory() {
        return history;
    }

    public void setHistory(String history) {
        this.history = history;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}

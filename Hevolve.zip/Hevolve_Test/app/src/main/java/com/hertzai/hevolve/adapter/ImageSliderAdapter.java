package com.hertzai.hevolve.adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.hertzai.hevolve.R;
import com.hertzai.hevolve.views.GridViewActivity;
import com.hertzai.hevolve.views.ImageSliderActivity;

import java.util.List;

public class ImageSliderAdapter extends PagerAdapter {
    private Context context;
    private LayoutInflater layoutInflater;
    private Integer [] images = {R.drawable.teach_apj_img,R.drawable.teach_breadman_img,R.drawable.teach_heisen_img,R.drawable.teach_newton_img,R.drawable.teach_panda_img,R.drawable.teach_santa_img,R.drawable.teach_shiv_img};

    public ImageSliderAdapter(Context context) {
        this.context = context;
    }
    @Override
    public int getCount() {
        return images.length;
    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return view == object;
    }
    @Override
    public Object instantiateItem(ViewGroup container, final int position) {

        layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View itemview = layoutInflater.inflate(R.layout.activity_slider_home, null);
        ImageView imageView = (ImageView) itemview.findViewById(R.id.teacher_imageView);
        imageView.setImageResource(images[position]);
        container.addView(itemview);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, GridViewActivity.class);
                intent.putExtra("MY_IMAGE", images[position]);
                context.startActivity(intent);
            }
        });


        return itemview;

    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);


    }
}

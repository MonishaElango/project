package com.hertzai.hevolve.views;


import android.Manifest;
import android.animation.Animator;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewTreeObserver;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.res.ResourcesCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.github.zagum.speechrecognitionview.RecognitionProgressView;
import com.google.api.gax.core.CredentialsProvider;
import com.google.api.gax.rpc.ApiStreamObserver;
import com.google.cloud.speech.v1.RecognitionConfig;
import com.google.cloud.speech.v1.SpeechClient;
import com.google.cloud.speech.v1.SpeechRecognitionAlternative;
import com.google.cloud.speech.v1.SpeechSettings;
import com.google.cloud.speech.v1.StreamingRecognitionConfig;
import com.google.cloud.speech.v1.StreamingRecognizeRequest;
import com.google.cloud.speech.v1.StreamingRecognizeResponse;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.protobuf.ByteString;
import com.hertzai.hevolve.R;
import com.hertzai.hevolve.adapter.AskMeChatRecyclerAdapter;
import com.hertzai.hevolve.api.AskMeChatApi;
import com.hertzai.hevolve.gson.AskMeAssis;
import com.hertzai.hevolve.gson.AskMessageItem;
import com.hertzai.hevolve.restService.ServiceGenerator;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicBoolean;

import kotlin.Lazy;
import kotlin.LazyKt;
import kotlin.Unit;
import kotlin.io.CloseableKt;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.converter.scalars.ScalarsConverterFactory;

public class AskMeChatActivity extends HeaderActivity implements HeaderActivity.onHeaderClickInterface, RecognitionListener, MessageDialogFragment.Listener {
    private ImageView sendButton;
    private RecyclerView mChatRecyclerView;
    private EditText chatET;
    private View headerLL;
    private TextView startTV;
    private String historyList ;
    private androidx.appcompat.widget.Toolbar myToolbar;
    private Integer time;
    private SpeechService.Listener mSpeechServiceListener;
    private ArrayList<AskMessageItem> messageList1;
    private AskMeChatRecyclerAdapter mAdapter;
    private LinearLayoutManager LinearLayoutManager;
    private RecognitionProgressView recognitionProgressView;
    private View background;

    private SpeechRecognizer speech = null;
    private Intent recognizerIntent;
    private ImageView micButton;
    private Boolean isMicOn = true;
    private Boolean isActivated= false;
    private String LOG_TAG = "VoiceRecognitionActivity";

    private final String clientId = "pe9cIH18BLCRMXcnpY2pPbaGpdWautlt";
    private final String clientSecret = "2KCbbah9FhFhl9a6zeVYNhEBagpFkHYh";






    private boolean mPermissionToRecord;
    private AudioEmitter mAudioEmitter;

    private static final String[] PERMISSIONS = new String[]{"android.permission.RECORD_AUDIO"};
    private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
    //    public static final MainActivity.Companion Companion = new MainActivity.Companion((DefaultConstructorMarker)null);
    private HashMap _$_findViewCache;






    private static final String FRAGMENT_MESSAGE_DIALOG = "message_dialog";

    private static final String STATE_RESULTS = "results";


    private SpeechService mSpeechService;
    // Resource caches
    private int mColorHearing;
    private int mColorNotHearing;

    private VoiceRecorder mVoiceRecorder;
    private final VoiceRecorder.Callback mVoiceCallback = new VoiceRecorder.Callback() {

        @Override
        public void onVoiceStart() {
            showStatus(true);
            if (mSpeechService != null) {
                mSpeechService.startRecognizing(mVoiceRecorder.getSampleRate());
            }
        }

        private void showStatus(final boolean hearingVoice) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    chatET.setTextColor(hearingVoice ? mColorHearing : mColorNotHearing);
                }
            });
        }

        @Override
        public void onVoice(byte[] data, int size) {
            if (mSpeechService != null) {
                mSpeechService.recognize(data, size);
            }
        }

        @Override
        public void onVoiceEnd() {
            showStatus(false);
            if (mSpeechService != null) {
                mSpeechService.finishRecognizing();
            }
        }

    };

    private final ServiceConnection mServiceConnection = new ServiceConnection() {



        @Override
        public void onServiceConnected(ComponentName componentName, IBinder binder) {
            mSpeechService = SpeechService.from(binder);
            mSpeechService.addListener(mSpeechServiceListener);
            chatET.setVisibility(View.VISIBLE);
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mSpeechService = null;
        }

    };



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_askme_chat);

        headerLL = findViewById(R.id.headerLL);
        micButton=findViewById(R.id.micBtn);
        background = findViewById(R.id.background);
       // myToolbar = findViewById(R.id.my_toolbar);
        //myToolbar.setTitle("Ask Assistant");
       // setSupportActionBar(myToolbar);
        messageList1 = new ArrayList<>();
        sendButton = findViewById(R.id.AskSendIcon);
        recognitionProgressView = findViewById(R.id.recognition_view);
        mChatRecyclerView = findViewById(R.id.AskChatRV);
        startTV = findViewById(R.id.AskStartTV);
        chatET = findViewById(R.id.AskChat_et);


        final Resources resources = getResources();
        final Resources.Theme theme = getTheme();
        mColorHearing = ResourcesCompat.getColor(resources, R.color.status_hearing, theme);
        mColorNotHearing = ResourcesCompat.getColor(resources, R.color.status_not_hearing, theme);


        initViews();


        int[] colors = {
                ContextCompat.getColor(AskMeChatActivity.this, R.color.color1),
                ContextCompat.getColor(AskMeChatActivity.this, R.color.color2),
                ContextCompat.getColor(AskMeChatActivity.this, R.color.color3),
                ContextCompat.getColor(AskMeChatActivity.this, R.color.color4),
                ContextCompat.getColor(AskMeChatActivity.this, R.color.color5)
        };




        if (savedInstanceState == null) {
            background.setVisibility(View.INVISIBLE);

            final ViewTreeObserver viewTreeObserver = background.getViewTreeObserver();

            if (viewTreeObserver.isAlive()) {
                viewTreeObserver.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

                    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                    @Override
                    public void onGlobalLayout() {
                        circularRevealActivity();
                        background.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    }

                });
            }

        }



        micButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

               // if (isMicOn) {
                   //isMicOn = false;

                    //speech.startListening(recognizerIntent);
                   // recognitionProgressView.setVisibility(View.VISIBLE);
               //// } else {
                   // speech.stopListening();
                  //  recognitionProgressView.setVisibility(View.INVISIBLE);
               //     isMicOn = true;
               // }

                mSpeechServiceListener =
                        new SpeechService.Listener() {
                            @Override
                            public void onSpeechRecognized(final String text, final boolean isFinal) {
                                if (isFinal) {
                                    mVoiceRecorder.dismiss();
                                }

                                //// ArrayList<String> matches = new ArrayList<>();

                                if (!TextUtils.isEmpty(text)) {
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            if (isFinal) {
                                                ArrayList<String> matches = new ArrayList<>();
                                                matches.add(text);
                                                if (matches != null && matches.size() > 0) {

                                                    messageList1.add(new AskMessageItem(matches.get(0), false));
                                                    mAdapter.notifyDataSetChanged();
                                                    startTV.setVisibility(View.GONE);
                                                    mChatRecyclerView.setVisibility(View.VISIBLE);
                                                    mChatRecyclerView.scrollToPosition(messageList1.size() - 1);
                                                    JSONObject obj = new JSONObject();

                                                    try {
                                                        obj.put("user", "user");
                                                        obj.put("history", historyList);
                                                        obj.put("text", messageList1.get(0).message);

                                                    } catch (JSONException e) {
                                                        e.printStackTrace();
                                                    }

                                                    JsonParser parser = new JsonParser();
                                                    JsonObject mainObj = (JsonObject) parser.parse(obj.toString());

                                                    sendRequest(mainObj);


                                                } else {
                                                    Toast.makeText(AskMeChatActivity.this, "Couldn't recognize your voice", Toast.LENGTH_SHORT).show();
                                                }

                                                String text1 = "";
                                                for (String results : matches)
                                                    text1 += results + "\n";
                                                chatET.setText(text1);
                                            }
                                        }
                                    });
                                }

                            }
                        };
            }
        });
    }

    private void startVoiceRecorder() {
        if (mVoiceRecorder != null) {
            mVoiceRecorder.stop();
        }
        mVoiceRecorder = new VoiceRecorder(mVoiceCallback);
        mVoiceRecorder.start();
    }

    private void stopVoiceRecorder() {
        if (mVoiceRecorder != null) {
            mVoiceRecorder.stop();
            mVoiceRecorder = null;
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        bindService(new Intent(this, SpeechService.class), mServiceConnection, BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        // Stop listening to voice
        stopVoiceRecorder();

        // Stop Cloud Speech API
        mSpeechService.removeListener(mSpeechServiceListener);
        unbindService(mServiceConnection);
        mSpeechService = null;

        super.onStop();
    }



    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void circularRevealActivity() {
        int cx = 0;
        int cy = 0;
        int right = 0;
        int bottom =0;
        int radius1 = (int) Math.hypot(right, bottom);

        float finalRadius = Math.max(background.getWidth(), background.getHeight());

        Animator circularReveal = ViewAnimationUtils.createCircularReveal(
                background,
                cx,
                cy,
                50,
                finalRadius);

        circularReveal.setDuration(500);
        background.setVisibility(View.VISIBLE);
        circularReveal.start();


    }

    private int getDips(int dps) {
        Resources resources = getResources();
        return (int) TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                dps,
                resources.getDisplayMetrics());
    }

    @Override
    public void onBackPressed() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            int cx = background.getLeft() - getDips(44);
            int cy = background.getBottom() - getDips(44);

            float finalRadius = Math.max(background.getWidth(), background.getHeight());
            Animator circularReveal = ViewAnimationUtils.createCircularReveal(background, cx, cy, finalRadius, 0);

            circularReveal.addListener(new Animator.AnimatorListener() {
                @Override
                public void onAnimationStart(Animator animator) {

                }

                @Override
                public void onAnimationEnd(Animator animator) {
                    background.setVisibility(View.INVISIBLE);
                    finish();
                }

                @Override
                public void onAnimationCancel(Animator animator) {

                }

                @Override
                public void onAnimationRepeat(Animator animator) {

                }
            });
            circularReveal.setDuration(500);
            circularReveal.start();
        } else {
            super.onBackPressed();
        }

    }


    private void initViews() {
        updateHeader(headerLL , true,"Ask An Assitant",this);
        mAdapter = new AskMeChatRecyclerAdapter(this, messageList1);
        LinearLayoutManager = new LinearLayoutManager(this);
        mChatRecyclerView.setLayoutManager(LinearLayoutManager);
        mChatRecyclerView.setAdapter(mAdapter);


        sendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String message = chatET.getText().toString();
                if (message.length() > 0) {
                    chatET.setText("");
                    mChatRecyclerView.setVisibility(View.VISIBLE);
                    startTV.setVisibility(View.GONE);
                    messageList1.add(new AskMessageItem(message, false));
                    mAdapter.notifyDataSetChanged();
                    mChatRecyclerView.scrollToPosition(messageList1.size() - 1);
                    JSONObject obj = new JSONObject();

                    try {
                        obj.put("user", "user");
                        obj.put("history",historyList);
                        obj.put("text", message);


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    JsonParser parser = new JsonParser();
                    JsonObject mainObj = new JsonObject();

                    mainObj = (JsonObject) parser.parse(obj.toString());

                    sendRequest(mainObj);


                } else {
                    Toast.makeText(AskMeChatActivity.this, "Please enter some text", Toast.LENGTH_SHORT).show();
                }


            }
        });

    }


    private void sendRequest(JsonObject message) {

        Gson gson = new GsonBuilder()
                .setLenient()
                .create();

        Retrofit retrofit = new Retrofit.Builder()

                .baseUrl("http://convai.mcgroce.com/")
                .addConverterFactory(ScalarsConverterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(gson))

                .build();

        AskMeChatApi service = retrofit.create(AskMeChatApi.class);

        Call<AskMeAssis> stringCall = service.getReply(message);
        stringCall.enqueue(new Callback<AskMeAssis>() {
            @Override
            public void onResponse(Call<AskMeAssis> call, Response<AskMeAssis> response) {
                if (!response.toString().equals("") || response.isSuccessful()) {
                    AskMeAssis jsonResponse = response.body();

                    if(jsonResponse != null ){
                     String   str  = jsonResponse.getText();
                     historyList = jsonResponse.getHistory();

                     //historyList = jsonResponse.getHistory();


                        messageList1.add(new AskMessageItem(str, true));
                        mChatRecyclerView.scrollToPosition(messageList1.size() - 1);
                        mAdapter.notifyDataSetChanged();

                    }
                }

            }

            @Override
            public void onFailure(Call<AskMeAssis> call, Throwable t) {
                Toast.makeText(AskMeChatActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();

            }
        });

    }




    @Override
    public void onBackClicked() {
        onBackPressed();
    }

    @Override
    public void onReadyForSpeech(Bundle bundle) {

    }

    @Override
    public void onBeginningOfSpeech() {

    }

    @Override
    public void onRmsChanged(float v) {

    }

    @Override
    public void onBufferReceived(byte[] bytes) {

    }

    @Override
    public void onEndOfSpeech() {

    }

    @Override
    public void onError(int i) {

    }

    @Override
    public void onResults(Bundle bundle) {

    }

    @Override
    public void onPartialResults(Bundle bundle) {

    }

    @Override
    public void onEvent(int i, Bundle bundle) {

    }


    @Override
    public void onMessageDialogDismissed() {

    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}

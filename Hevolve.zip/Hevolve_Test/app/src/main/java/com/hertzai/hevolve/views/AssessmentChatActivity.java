    package com.hertzai.hevolve.views;

    import android.animation.Animator;
    import android.app.Activity;
    import android.content.Context;
    import android.content.Intent;
    import android.content.res.Resources;
    import android.os.Build;
    import android.os.Bundle;
    import android.speech.RecognitionListener;
    import android.speech.RecognizerIntent;
    import android.speech.SpeechRecognizer;
    import android.util.Log;
    import android.util.TypedValue;
    import android.view.View;
    import android.view.ViewAnimationUtils;
    import android.view.ViewTreeObserver;
    import android.widget.EditText;
    import android.widget.ImageView;
    import android.widget.TextSwitcher;
    import android.widget.TextView;
    import android.widget.Toast;

    import androidx.annotation.RequiresApi;
    import androidx.core.app.ActivityCompat;
    import androidx.core.content.ContextCompat;
    import androidx.recyclerview.widget.LinearLayoutManager;
    import androidx.recyclerview.widget.RecyclerView;

    import com.github.zagum.speechrecognitionview.RecognitionProgressView;
    import com.google.api.gax.core.CredentialsProvider;
    import com.google.api.gax.rpc.ApiStreamObserver;
    import com.google.cloud.speech.v1.RecognitionConfig;
    import com.google.cloud.speech.v1.SpeechClient;
    import com.google.cloud.speech.v1.SpeechRecognitionAlternative;
    import com.google.cloud.speech.v1.SpeechSettings;
    import com.google.cloud.speech.v1.StreamingRecognitionConfig;
    import com.google.cloud.speech.v1.StreamingRecognizeRequest;
    import com.google.cloud.speech.v1.StreamingRecognizeResponse;
    import com.google.gson.Gson;
    import com.google.gson.GsonBuilder;
    import com.google.gson.JsonObject;
    import com.google.gson.JsonParser;
    import com.google.protobuf.ByteString;
    import com.hertzai.hevolve.R;
    import com.hertzai.hevolve.adapter.AssessChatRecyclerAdapter;
    import com.hertzai.hevolve.api.AssessChatApi;
    import com.hertzai.hevolve.gson.Assess_ResponseMessage;

    import org.jetbrains.annotations.NotNull;
    import org.json.JSONArray;
    import org.json.JSONException;
    import org.json.JSONObject;

    import java.io.Closeable;
    import java.io.IOException;
    import java.io.InputStream;
    import java.util.ArrayList;
    import java.util.HashMap;
    import java.util.concurrent.atomic.AtomicBoolean;

    import kotlin.Lazy;
    import kotlin.LazyKt;
    import kotlin.Unit;
    import kotlin.jvm.functions.Function0;
    import kotlin.jvm.functions.Function1;
    import kotlin.jvm.internal.Intrinsics;
    import retrofit2.Call;
    import retrofit2.Callback;
    import retrofit2.Response;
    import retrofit2.Retrofit;
    import retrofit2.converter.gson.GsonConverterFactory;

    public class AssessmentChatActivity extends HeaderActivity implements HeaderActivity.onHeaderClickInterface, RecognitionListener {
        private ImageView sendButton;
        private ImageView micButton;
        private TextView startText;
        private RecyclerView mChatRecyclerView;
        private View headerLL;
        private EditText chatET;
        private TextView optionTV;
        private ArrayList<QuestionNo> messageList;
        private ArrayList<Revision_No> messageList1;

        private AssessChatRecyclerAdapter mAdapter;
        private LinearLayoutManager LinearLayoutManager;
        private String assessment = "false";
        private androidx.appcompat.widget.Toolbar myToolbar1;
        private Integer questionNumber = 0;
        private String subject = "";
        private String student_id = "";
        private Integer assessmentId = 0;
        private String qlist = "";

        private Boolean isMicOn = true;
        private RecognitionProgressView recognitionProgressView;
        private View background;
        private SpeechRecognizer speech = null;
        private Intent recognizerIntent;
        private SpeechRecognizer speechRecognizer;
        private String LOG_TAG = "VoiceRecognitionActivity";
        private ArrayList<String> optionList = new ArrayList<>();
        private boolean mPermissionToRecord;
        private AudioEmitter mAudioEmitter;
        private final Lazy mSpeechClient$delegate = LazyKt.lazy((Function0) (new Function0() {
            // $FF: synthetic method
            // $FF: bridge method
    //        public Object invoke() {
    //            return this.invoke();
    //        }


            public final SpeechClient invoke() {
                Context var10000 = AssessmentChatActivity.this.getApplicationContext();
                Intrinsics.checkExpressionValueIsNotNull(var10000, "applicationContext");
                Closeable var1 = (Closeable) var10000.getResources().openRawResource(R.raw.credential);
                boolean var2 = false;
                Throwable var3 = (Throwable) null;

                SpeechClient var10 = null;
                try {
                    InputStream it = (InputStream) var1;
    //                int var5 = false;
                    var10 = SpeechClient.create(((SpeechSettings.Builder) SpeechSettings.newBuilder().setCredentialsProvider((CredentialsProvider) (new MainActivity$mSpeechClient$2$1$1(it)))).build());
                } catch (Throwable var8) {
                    var3 = var8;
                    try {
                        throw var8;
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } finally {
                    //CloseableKt.closeFinally(var1, var3);
                    Log.d("Speech", "invoke: inside finally block!!");
                }

                return var10;
            }
        }));
        private static final String[] PERMISSIONS = new String[]{"android.permission.RECORD_AUDIO"};
        private static final int REQUEST_RECORD_AUDIO_PERMISSION = 200;
        //    public static final MainActivity.Companion Companion = new MainActivity.Companion((DefaultConstructorMarker)null);
        private HashMap _$_findViewCache;

        private final SpeechClient getMSpeechClient() {
            Lazy var1 = this.mSpeechClient$delegate;
            Object var3 = null;
            boolean var4 = false;
            return (SpeechClient) var1.getValue();
        }



        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);


            setContentView(R.layout.activity_assess_chat);

            messageList = new ArrayList<>();
            sendButton = findViewById(R.id.sendIcon);
            startText = findViewById(R.id.startTV);
            headerLL = findViewById(R.id.headerLL);
            mChatRecyclerView = findViewById(R.id.chatRV);
            chatET = findViewById(R.id.chat_et);
            optionTV=findViewById(R.id.option_tv);
            micButton = findViewById(R.id.micBtn);
    //        myToolbar1 =  findViewById(R.id.my_toolbar1);
    //        myToolbar1.setTitle("Assess My Skill");
    //        setSupportActionBar(myToolbar1);
            recognitionProgressView = findViewById(R.id.recognition_view1);
            initiateSpeech();
            initViews();


            int[] colors = {
                    ContextCompat.getColor(AssessmentChatActivity.this, R.color.color1),
                    ContextCompat.getColor(AssessmentChatActivity.this, R.color.color2),
                    ContextCompat.getColor(AssessmentChatActivity.this, R.color.color3),
                    ContextCompat.getColor(AssessmentChatActivity.this, R.color.color4),
                    ContextCompat.getColor(AssessmentChatActivity.this, R.color.color5)
            };


            overridePendingTransition(R.anim.do_not_move, R.anim.do_not_move);
            background = findViewById(R.id.background1);
            if (savedInstanceState == null) {
                background.setVisibility(View.INVISIBLE);

                final ViewTreeObserver viewTreeObserver = background.getViewTreeObserver();

                if (viewTreeObserver.isAlive()) {
                    viewTreeObserver.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {

                        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
                        @Override
                        public void onGlobalLayout() {
                            circularRevealActivity();
                            background.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        }

                    });
                }

            }


            ActivityCompat.requestPermissions((Activity) this, PERMISSIONS, 200);
            View var10001 = this.findViewById(R.id.chat_et);

            Intrinsics.checkExpressionValueIsNotNull(var10001, "findViewById(R.id.chat_et)");

            recognitionProgressView.setSpeechRecognizer(speech);
            recognitionProgressView.setColors(colors);
            recognitionProgressView.setCircleRadiusInDp(2);
            recognitionProgressView.setSpacingInDp(2);
            recognitionProgressView.setIdleStateAmplitudeInDp(2);
            recognitionProgressView.setRotationRadiusInDp(10);
            recognitionProgressView.play();
            recognitionProgressView.setRecognitionListener(this);

          micButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    recognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                    if(isMicOn){
                        isMicOn = false;
                        speech.startListening(recognizerIntent);
                        recognitionProgressView.setVisibility(View.VISIBLE);
                    }else {
                        speech.stopListening();
                        recognitionProgressView.setVisibility(View.INVISIBLE);
                        isMicOn = true;
                    }


                    if (mPermissionToRecord) {
                            final AtomicBoolean isFirstRequest = new AtomicBoolean(true);
                            mAudioEmitter = new AudioEmitter();
                            final ApiStreamObserver requestStream = getMSpeechClient().streamingRecognizeCallable().bidiStreamingCall((ApiStreamObserver) (new ApiStreamObserver() {

                                public void onNext(@NotNull final StreamingRecognizeResponse value) {
                                    Intrinsics.checkParameterIsNotNull(value, "value");
                                    AssessmentChatActivity.this.runOnUiThread((Runnable) (new Runnable() {
                                        public final void run() {
                                            if(!isMicOn){
                                                if(mAudioEmitter != null) {
                                                    if (value.getResultsCount() > 0) {
    //                                                TextSwitcher var10000 = AssessmentChatActivity.access$getMTextView$p(AssessmentChatActivity.this);
                                                        SpeechRecognitionAlternative var10001 = value.getResults(0).getAlternatives(0);
                                                        Intrinsics.checkExpressionValueIsNotNull(var10001, "value.getResults(0).getAlternatives(0)");
    //                                                var10000.setText((CharSequence) var10001.getTranscript());

                                                        String result = ((CharSequence) var10001.getTranscript()).toString();
                                                        ArrayList<String> matches = new ArrayList<>();
                                                        matches.add(result);
                                                        if (matches != null && matches.size() > 0) {
                                                            messageList.add(new QuestionNo("", matches, optionList,false));

                                                            mAdapter.notifyDataSetChanged();
                                                            startText.setVisibility(View.GONE);
                                                            mChatRecyclerView.setVisibility(View.VISIBLE);
                                                            questionNumber +=1;
                                                            mChatRecyclerView.scrollToPosition(messageList.size() - 1);
                                                            JSONObject obj = new JSONObject();
                                                            JSONArray array = new JSONArray();

                                                            try {


                                                                array.put(matches);
                                                                obj.put("text", array);
                                                                obj.put("assessment", assessment);
                                                                obj.put("subject", subject);
                                                                obj.put("question_no", questionNumber.toString());

                                                            } catch (JSONException e) {
                                                                e.printStackTrace();
                                                            }

                                                            JsonParser parser = new JsonParser();
                                                            JsonObject mainObj = new JsonObject();

                                                            mainObj = (JsonObject) parser.parse(obj.toString());

                                                            sendRequest(mainObj);


                                                        } else {
                                                            Toast.makeText(AssessmentChatActivity.this, "Couldn't recognize your voice", Toast.LENGTH_SHORT).show();
                                                        }
                                                        String text = "";
                                                        for (String results : matches)
                                                            text += results + "\n";

                                                        chatET.setText(text);


                                                    } else {
                                                        Toast.makeText(AssessmentChatActivity.this, "Couldn't start", Toast.LENGTH_SHORT).show();
                                                    }
                                                }else{
                                                    Toast.makeText(AssessmentChatActivity.this, "Mic off", Toast.LENGTH_SHORT).show();

                                                }
                                            }else{
                                                Toast.makeText(AssessmentChatActivity.this, "Mic off", Toast.LENGTH_SHORT).show();

                                            }
                                        }
                                    }));
                                }

                                // $FF: synthetic method
                                // $FF: bridge method
                                public void onNext(Object var1) {
                                    this.onNext((StreamingRecognizeResponse) var1);
                                }

                                public void onError(@NotNull Throwable t) {
                                    Intrinsics.checkParameterIsNotNull(t, "t");
                                    Log.e("Speech", "an error occurred", t);
                                }

                                public void onCompleted() {
                                    Log.d("Speech", "stream closed");
                                }
                            }));
                            AudioEmitter var10000 = mAudioEmitter;
                            if (var10000 == null) {
                                Intrinsics.throwNpe();
                            }

                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                                AudioEmitter.start$default(var10000, 0, 0, 0, (Function1) (new Function1() {
                                    public Object invoke(Object var1) {
                                        this.invoke((ByteString) var1);
                                        return Unit.INSTANCE;
                                    }

                                    public final void invoke(@NotNull ByteString bytes) {
                                        Intrinsics.checkParameterIsNotNull(bytes, "bytes");
                                        StreamingRecognizeRequest.Builder builder = StreamingRecognizeRequest.newBuilder().setAudioContent(bytes);
                                        if (isFirstRequest.getAndSet(false)) {
                                            Intrinsics.checkExpressionValueIsNotNull(builder, "builder");
                                            builder.setStreamingConfig(StreamingRecognitionConfig.newBuilder().setConfig(RecognitionConfig.newBuilder().setLanguageCode("en-US").setEncoding(RecognitionConfig.AudioEncoding.LINEAR16).setSampleRateHertz(16000).build()).setInterimResults(false).setSingleUtterance(false).build());
                                        }

                                        requestStream.onNext(builder.build());
                                    }
                                }), 7, (Object) 1);
                            }
                        } else {
                            Log.e("Speech", "No permission to record! Please allow and then relaunch the app!");
                        }

                    }
    //                else if (texts.equals("stop")) {
    //               //     start.setText("startListening");
    //                    AudioEmitter var10000 = mAudioEmitter;
    //                    if (var10000 != null) {
    //                        var10000.stop();
    //                    }
    //
    //                    mAudioEmitter = (AudioEmitter) null;
    //                }
                });
            }

        private void initiateSpeech() {
            if(speech != null)
                speech.destroy();
            speech = SpeechRecognizer.createSpeechRecognizer(this);
            Log.i(LOG_TAG, "isRecognitionAvailable: " + SpeechRecognizer.isRecognitionAvailable(this));
            if(SpeechRecognizer.isRecognitionAvailable(this))
                speech.setRecognitionListener(this);
        }


        protected void onResume () {
                super.onResume();
            }

            protected void onPause () {
                super.onPause();
                AudioEmitter var10000 = this.mAudioEmitter;
                if (var10000 != null) {
                    var10000.stop();
                }

                this.mAudioEmitter = (AudioEmitter) null;
            }

            protected void onDestroy () {
                super.onDestroy();
                //getMSpeechClient().shutdown();
            }

            public void onRequestPermissionsResult ( int requestCode, @NotNull String[] permissions,
            @NotNull int[] grantResults){
                Intrinsics.checkParameterIsNotNull(permissions, "permissions");
                Intrinsics.checkParameterIsNotNull(grantResults, "grantResults");
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
                if (requestCode == 200) {
                    this.mPermissionToRecord = grantResults[0] == 0;
                }

                if (!this.mPermissionToRecord) {
                    this.finish();
                }

            }

    //        // $FF: synthetic method
    //        public static final TextSwitcher access$getMTextView$p (AssessmentChatActivity $this){
    //            TextSwitcher var10000 = $this.mTextView;
    //            if (var10000 == null) {
    //                Intrinsics.throwUninitializedPropertyAccessException("mTextView");
    //            }
    //
    //            return var10000;
    //        }

            // $FF: synthetic method
            public static final void access$setMTextView$p (AssessmentChatActivity $this, TextSwitcher
            var1){
            //    $this.mTextView = var1;
            }

            public View _$_findCachedViewById ( int var1){
                if (this._$_findViewCache == null) {
                    this._$_findViewCache = new HashMap();
                }

                View var2 = (View) this._$_findViewCache.get(var1);
                if (var2 == null) {
                    var2 = this.findViewById(var1);
                    this._$_findViewCache.put(var1, var2);
                }

                return var2;
            }

            public void _$_clearFindViewByIdCache () {
                if (this._$_findViewCache != null) {
                    this._$_findViewCache.clear();
                }

            }

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            private void circularRevealActivity () {
                int cx = background.getRight() - getDips(60);
                int cy = background.getBottom() - getDips(500);

                float finalRadius = Math.max(background.getWidth(), background.getHeight());

                Animator circularReveal = ViewAnimationUtils.createCircularReveal(
                        background,
                        cx,
                        cy,
                        50,
                        finalRadius);

                circularReveal.setDuration(500);
                background.setVisibility(View.VISIBLE);
                circularReveal.start();

            }

            private int getDips ( int dps){
                Resources resources = getResources();
                return (int) TypedValue.applyDimension(
                        TypedValue.COMPLEX_UNIT_DIP,
                        dps,
                        resources.getDisplayMetrics());
            }

            @Override
            public void onBackPressed () {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    int cx = background.getWidth() - getDips(44);
                    int cy = background.getBottom() - getDips(44);

                    float finalRadius = Math.max(background.getWidth(), background.getHeight());
                    Animator circularReveal = ViewAnimationUtils.createCircularReveal(background, cx, cy, finalRadius, 0);

                    circularReveal.addListener(new Animator.AnimatorListener() {
                        @Override
                        public void onAnimationStart(Animator animator) {

                        }

                        @Override
                        public void onAnimationEnd(Animator animator) {
                            background.setVisibility(View.INVISIBLE);
                            finish();
                        }

                        @Override
                        public void onAnimationCancel(Animator animator) {

                        }

                        @Override
                        public void onAnimationRepeat(Animator animator) {

                        }
                    });
                    circularReveal.setDuration(500);
                    circularReveal.start();
                } else {
                    super.onBackPressed();
                }
            }

        private void initViews(){

            updateHeader(headerLL , true,"Assess My Skill",this);
            mAdapter = new AssessChatRecyclerAdapter(this, messageList, new AssessChatRecyclerAdapter.ChatInterface() {
                @Override
                public void onOptionClicked(String option) {

                    updateText(option);
                }
            });
            LinearLayoutManager = new LinearLayoutManager(this);
            mChatRecyclerView.setLayoutManager(LinearLayoutManager);
            mChatRecyclerView.setAdapter(mAdapter);

            sendButton.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View view) {
                    updateText(chatET.getText().toString());
                }
            });
        }


        void updateText(String message){
            ArrayList<String> qlistString = new ArrayList<>();

            ArrayList<String> messageStringList = new ArrayList<>();
            messageStringList.clear();
            messageStringList.add(message);
            if(message.length() > 0){
                chatET.setText("");
                messageList.add(new QuestionNo("",messageStringList ,optionList, false));
            //    mAdapter.notifyDataSetChanged();
                startText.setVisibility(View.GONE);
                mChatRecyclerView.setVisibility(View.VISIBLE);

                mChatRecyclerView.scrollToPosition(messageList.size()-1);
                JSONObject obj = new JSONObject();
                JSONArray array = new JSONArray();


                try{

                    array.put(message);
                    obj.put("text", array);
                    /* obj.put("user_id" , username);*/
                    obj.put("assessment" , assessment);
                    obj.put("subject",subject);
                    obj.put("student_id","2");
                    obj.put("assessment_id", assessmentId.toString());
                    obj.put("qlist",qlist);
                    obj.put("question_no" , questionNumber.toString());

                }catch ( JSONException e){
                    e.printStackTrace();
                }

                JsonParser parser = new JsonParser();
                JsonObject mainObj = new JsonObject();

                mainObj = (JsonObject)  parser.parse(obj.toString());

                sendRequest(mainObj);

            }else{
                Toast.makeText(AssessmentChatActivity.this,"Please enter some text" , Toast.LENGTH_SHORT).show();
            }
        }

        private void sendRequest(JsonObject message){

            Gson gson = new GsonBuilder()
                    .setLenient()
                    .create();

            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl("http://assess.mcgroce.com")
                   .addConverterFactory(GsonConverterFactory.create())
                    .build();

            AssessChatApi service = retrofit.create(AssessChatApi.class);

            Call<Assess_ResponseMessage> stringCall = service.getReply(message);
            stringCall.enqueue(new Callback<Assess_ResponseMessage>() {
                @Override
                public void onResponse(Call<Assess_ResponseMessage> call, Response<Assess_ResponseMessage> response){
                        if (!response.toString().equals("") || response.isSuccessful()) {
                            Assess_ResponseMessage jsonResponse = response.body();

                            if(jsonResponse != null ){
                                System.out.println(jsonResponse);
                                assessment  = jsonResponse.getAssessment();
                                student_id = jsonResponse.getStudent_id();
                                assessmentId = jsonResponse.getAssessment_id();
                                qlist = jsonResponse.getQlist();
                                subject =jsonResponse.getSubject();



                               // if(Integer.parseInt(jsonResponse.getQuestionNo().toString()) > 0)
                                //{
                                   // questionNumber = Integer.parseInt(jsonResponse.getQuestionNo().toString());
                                  //  messageList.add(new QuestionNo(questionNumber.toString(),jsonResponse.getAnswerList(),jsonResponse.getOptionLists(), true));

                               // }
                              //  else{
                                 //   messageList1.add(new Revision_No(jsonResponse.getAnswerList(),true, jsonResponse.getOptionLists()));
                               // };
                              //if(jsonResponse.getQuestionNo() > 0)
                                // {
                                  // questionNumber = Integer.parseInt(jsonResponse.getQuestionNo().toString());

                               // }
                                questionNumber = Integer.parseInt(jsonResponse.getQuestionNo().toString());
                                messageList.add(new QuestionNo(questionNumber.toString(),jsonResponse.getAnswerList(),jsonResponse.getOptionLists(), true));

                                if(jsonResponse.getOptionLists()!=null) {
                                    if(assessment.equals("True")) {
                                        optionList.addAll(jsonResponse.getOptionLists());
                                    }
                                    else{
                                        optionList.clear();
                                    }
                                }
                                mChatRecyclerView.scrollToPosition(messageList.size() - 1);
                                mAdapter.notifyDataSetChanged();

                            }else{
                                Toast.makeText(AssessmentChatActivity.this,"Not getting any response",Toast.LENGTH_LONG).show();

                            }
                        }


                }

                @Override
                public void onFailure(Call<Assess_ResponseMessage> call, Throwable t) {
                    Toast.makeText(AssessmentChatActivity.this,t.getMessage(),Toast.LENGTH_LONG).show();
                }
            });

        }



        @Override

        public void onBackClicked() {
            onBackPressed();
        }

        @Override
        public void onReadyForSpeech(Bundle bundle) {

        }

        @Override
        public void onBeginningOfSpeech() {

        }

        @Override
        public void onRmsChanged(float v) {

        }

        @Override
        public void onBufferReceived(byte[] bytes) {

        }

        @Override
        public void onEndOfSpeech() {

        }

        @Override
        public void onError(int i) {

        }

        @Override
        public void onResults(Bundle bundle) {

        }

        @Override
        public void onPartialResults(Bundle bundle) {

        }

        @Override
        public void onEvent(int i, Bundle bundle) {

        }
    }
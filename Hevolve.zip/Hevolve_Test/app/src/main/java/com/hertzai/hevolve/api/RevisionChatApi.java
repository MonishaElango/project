package com.hertzai.hevolve.api;

import com.google.gson.JsonObject;
import com.hertzai.hevolve.gson.Revision_Response_Message;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.POST;

public interface RevisionChatApi {
    @POST("revision")
    @Headers("Content-Type: application/json")
    Call<Revision_Response_Message> getReply(@Body JsonObject jsonObject);
}

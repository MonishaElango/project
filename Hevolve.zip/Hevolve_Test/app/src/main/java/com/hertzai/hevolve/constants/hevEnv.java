package com.hertzai.hevolve.constants;

public class hevEnv {

    //App mode
    public static final String PROD_MODE = "0";
    public static final String STAGING_MODE = "1";
    public static final String DEV_MODE = "2";
}

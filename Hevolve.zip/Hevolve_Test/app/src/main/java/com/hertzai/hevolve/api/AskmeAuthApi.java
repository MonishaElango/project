package com.hertzai.hevolve.api;

import com.google.auth.oauth2.AccessToken;
import com.google.gson.JsonObject;
import com.hertzai.hevolve.gson.AskMeAssis;

import io.reactivex.Observable;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Url;

public interface AskmeAuthApi {

    @POST("token")
    @Headers("Content-type: application/json")
    Call<AccessToken> getAccessToken(@Body JsonObject jsonObject,
    @Field("client_id") String clientID,
   @Field("client_secret") String clientSecret,
  @Field("code") String code);

}

package com.hertzai.hevolve.views;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.hertzai.hevolve.R;

public class HeaderActivity  extends AppCompatActivity {

    TextView titleTV  ;
    ImageView backIV;

    void updateHeader(View view , Boolean isShowBack,String title  , onHeaderClickInterface  Interface){
        titleTV = view.findViewById(R.id.titleTV);
        backIV =  view.findViewById(R.id.backIV);

        titleTV.setText(title);

        if(isShowBack){
            backIV.setVisibility(View.VISIBLE);
        }else{
            backIV.setVisibility(View.GONE);
        }

        backIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Interface.onBackClicked();
            }
        });

    }

    interface onHeaderClickInterface{
        void onBackClicked();
    }
}